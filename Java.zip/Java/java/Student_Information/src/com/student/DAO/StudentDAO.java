package com.student.DAO;

import java.util.List;

import com.student.Entity.Student;

public interface StudentDAO {

	boolean addStd(Student s);

	List<Student> displayStd();

	Student findByRno(int rno);

	List<Student> DisplayByName(String name);

	boolean deleteStudentByR(int rno);

	boolean modifyName(int rno, String name);

	List<Student> arrangeByName();

	List<Student> arrangeByRno();

}
