package com.student.Service;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.List;
import java.util.Scanner;

import com.student.DAO.StudentDAO;
import com.student.DAO.StudentDAOImpl;
import com.student.Entity.Student;

public class StudentServiceImpl implements StudentService {
	StudentDAO std = new StudentDAOImpl();

	@Override
	public boolean addStudents() {
		Student s ;
		Scanner sc = new Scanner(System.in);
		
		System.out.println("Enter The RollNo :");
		int rno = sc.nextInt();
		System.out.println("Enter the Name :");
		String name = sc.next();
		System.out.println("Enter Your Standred :");
		String st = sc.next();
		System.out.println("Enter the Percentage :");
		double per = sc.nextDouble();
		System.out.println("Enter the Email :");
		String mail = sc.next();
		System.out.println("Enter the Mobile Number :");
		String mob = sc.next();
		System.out.println("Enter your Birth Date (dd/mm/yyyy) ;");
		String dt = sc.next();
		SimpleDateFormat date = new SimpleDateFormat("dd/mm/yyyy");
		Date doj = null;
		
		try {
			doj = date.parse(dt);
			
		}catch(ParseException e)
		{
			e.printStackTrace();
		}
		s = new Student(rno, name, st, per, mail, mob, doj);
		return std.addStd(s);
		
		
	}

	@Override
	public List<Student> displayStd() {
		
		return std.displayStd();
		
	}
	

	@Override
	public Student findByRno(int rno) {
		return std.findByRno(rno);
	}

	@Override
	public List<Student> findByName(String name) {
		return std.DisplayByName(name);
	}

	@Override
	public boolean deleteByRollNo(int rno) {
		return std.deleteStudentByR(rno);
	}

	@Override
	public boolean modifyName(int rno, String name) {
		return std.modifyName(rno,name);
	}

	@Override
	public List<Student> sortByName() {
		return std.arrangeByName();
	}

	@Override
	public List<Student> sortByRollno() {
		return std.arrangeByRno();
	}
	
}
