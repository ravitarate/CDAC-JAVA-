package com.student.Service;

import java.util.List;

import com.student.Entity.Student;

public interface StudentService {

	boolean addStudents();

	List<Student> displayStd();

	Student findByRno(int rno);

	List<Student> findByName(String name);

	boolean deleteByRollNo(int rno);

	boolean modifyName(int rno, String name);

	List<Student> sortByName();

	List<Student> sortByRollno();

}
