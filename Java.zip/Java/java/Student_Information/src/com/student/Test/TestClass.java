package com.student.Test;

import java.util.List;
import java.util.Scanner;

import com.student.Entity.Student;
import com.student.Service.StudentService;
import com.student.Service.StudentServiceImpl;

public class TestClass {

	public static void main(String[] args) {
		StudentService stds = new StudentServiceImpl();
		Scanner sc = new Scanner(System.in);
	
			
			int choice;
			
			do {
				System.out.println("1. Adding the new Students");
				System.out.println("2. Display the Students");
				System.out.println("3. Find Student By RollNo");
				System.out.println("4. Find Students By Name");
				System.out.println("5. Delete Student by RollNo");
				System.out.println("6. Modify Student by Name");
				System.out.println("7. display in sorted order by name");
				System.out.println("8. Display in sorted order by RollNo");
				System.out.println("9. Exit");
				System.out.println("Enter Your Choice :");
				choice = sc.nextInt();
				
				switch (choice) {
				
				case 1:
					boolean flag = stds.addStudents();
					if(flag)
					{
						System.out.println("Added Sccess.....");
					}
					else {
						System.out.println("Error");
					}
					break;
				
				case 2:
					List<Student> student = stds.displayStd();
					student.forEach(e-> System.out.println(e));
					
					break;
					
				case 3:
					System.out.println("Enter The RollNo :");
					int rno = sc.nextInt();
					Student s= stds.findByRno(rno);
					if(s != null)
					{
						System.out.println(s);
					}else {
						System.out.println("not found");
					}
					break;
					
				case 4:
					System.out.println("Enter the Name :");
					String name = sc.next();
					student = stds.findByName(name);
					if(!student.isEmpty())
					{
						student.forEach(e-> System.out.println(e));
					}else {
						System.out.println("not found");
					}
					break;
					
				case 5:
					System.out.println("Enter roll no to delete student :");
					rno = sc.nextInt();
					
					if(stds.deleteByRollNo(rno))
					{
						System.out.println("Deleted the student");
					}else {
						System.out.println("not found");
					}
					break;
					
				case 6:
					System.out.println("Enter The RollNo :");
					 rno = sc.nextInt();
					System.out.println("Enter the Name :");
					name = sc.next();
					if(stds.modifyName(rno,name)) {
						System.out.println("Modify the student name");
					}else {
						System.out.println("not found");
					}
					break;
					
				case 7:
					student = stds.sortByName();
					student.forEach(System.out::println);
					break;
					
				case 8:
					student = stds.sortByRollno();
					student.forEach(System.out::println);
					break;
					
				case 9:
					sc.close();
					System.out.println("Exit");
					break;
					
				default :
					System.out.println("Thank You.........");
					break;
				}

			}while(choice != 9);

	}
}
