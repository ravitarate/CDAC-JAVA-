package IETCDAC;

public class Student {

	public static void main(String[] args) {
		StudentDriver sd = new StudentDriver(23,"Dinesh",65,39,78);
		System.out.println(sd);
	}

}
