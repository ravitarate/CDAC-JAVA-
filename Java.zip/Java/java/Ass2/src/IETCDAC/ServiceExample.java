package IETCDAC;

public class ServiceExample {
	private int sid;
	private String name;
	private long no;
	
	ServiceExample(int sid, String name, long no){
		this.sid = sid;
		this.name = name;
		this.no = no;
	}
	public void setSid(int sid) {
		this.sid = sid;
	}
	public void setName(String name) {
		this.name = name;
	}
	public void setNo(long no) {
		this.no = no;
	}
	
	public int getSid() {
		return sid;
	}
	public String getName() {
		return name;
	}
	public long getNo() {
		return no;
	}
	
	public String toString() {
		return "student id :"+sid+"\nstudent name :"+name+"\n student Number :"+no;
	}
}
