import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;

public class TestFile {

	public static void main(String[] args) {
		
		FileInputStream fis=null;
		FileOutputStream fos =null;
		try {
			fos = new FileOutputStream("Democopy.txt");
			fis= new FileInputStream("Demo.txt");
			
			int i = 0;
			while(i!=-1) {
				fos.write(i);
				i=fis.read();
			}
		}
		catch(FileNotFoundException e)
		{
			e.printStackTrace();
		} catch (IOException e) {
			
			e.printStackTrace();
		}
		finally {
			try {
				if(fos!=null)
				fos.close();
				if(fis!=null)
				fis.close();
			}
			catch (IOException e) {
				e.printStackTrace();
			}
		}

	}

}
