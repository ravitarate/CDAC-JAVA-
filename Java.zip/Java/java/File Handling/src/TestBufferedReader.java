import java.io.BufferedInputStream;
import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;

public class TestBufferedReader {

	public static void main(String[] args) {
//		try(BufferedReader br = new BufferedReader(new FileReader("employee.txt"))) {
//			String data = br.readLine();
//			double sum = 0;
//			while(data!=null) {
//				String[] arr = data.split(",");
//				sum+= Double.parseDouble(arr[2]);
//				System.out.println("id "+arr[0]+"\n Name :"+arr[1]+"\n"+"Sal :"+arr[2]);
//				System.out.println("---------------------");
//				data=br.readLine();
//			}
//			
//			System.out.println("Total :"+sum);
//		} catch (FileNotFoundException e) {
//			e.printStackTrace();
//		} catch (IOException e) {
//			
//			e.printStackTrace();
//		}
//
//	}

		
		try(BufferedWriter br = new BufferedWriter (new FileWriter("employee.txt"))) {
			
			br.write(107);
			br.write("Rajesh");
			br.write(3474);
			System.out.println("data append");
			
		} catch (FileNotFoundException e) {
			e.printStackTrace();
		} catch (IOException e) {
			
			e.printStackTrace();
		}

	}
}
