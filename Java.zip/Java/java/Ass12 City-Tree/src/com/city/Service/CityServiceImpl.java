package com.city.Service;

import java.util.List;
import java.util.Map;

import com.city.DAO.CityDao;
import com.city.DAO.CityDaoImpl;
import com.city.Entity.City;
import com.city.Entity.Trees;

public class CityServiceImpl implements CityService {
	CityDao cdao = new CityDaoImpl();

	@Override
	public List<Trees> findTreeList(String cname) {
		return cdao.showTreesForCity(cname);
	}

	@Override
	public boolean deleteTreeList(String cname) {
		return cdao.removeTreeList(cname);
	}

	@Override
	public Map<City, Trees> displayData() {
		return cdao.findAll();
	}
	
	

}
