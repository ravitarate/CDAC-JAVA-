package com.city.DAO;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.TreeMap;

import com.city.Entity.City;
import com.city.Entity.Trees;

public class CityDaoImpl implements CityDao {
	
	static Map<City,Trees> cmap= new TreeMap<>();
	
	static {
		List<String> tree = new ArrayList<>();
		tree.add("Peepal");
		tree.add("Gulmohar");
		tree.add("Coconut");
		
		cmap.put(new City("Nashik"),new Trees(tree));
		
		
		List<String> tree1 = new ArrayList<>();
		tree1.add("neem");
		tree1.add("Mango");
		tree1.add("Coconut");
		
		cmap.put(new City("Pune"),new Trees(tree1));

	}

	@Override
	public List<Trees> showTreesForCity(String cname) {
		
		List<Trees> tlist = new ArrayList<>();
		
		if(cmap.containsKey(new City(cname)))
		{
			tlist.add(cmap.get(new City(cname)));
			return tlist;
			
		}
		return null;
	}

	@Override
	public boolean removeTreeList(String cname) {
		
		if(cmap.containsKey(new City(cname)))
		{
			cmap.put(new City(cname), null);
			return true;
		}
		return false;
	}

	@Override
	public Map<City, Trees> findAll() {
		return cmap;
	}
	
	
	
	
}
