package com.city.DAO;

import java.util.List;
import java.util.Map;

import com.city.Entity.City;
import com.city.Entity.Trees;

public interface CityDao {

	List<Trees> showTreesForCity(String cname);

	boolean removeTreeList(String cname);

	Map<City, Trees> findAll();

}
