import java.util.Date;
import java.util.Scanner;

public class ExamSerivce {
	static int cnt = 100;
	
	//Java questions Array
	 Questions[] javaQuestions = new Questions[]{
	            new Questions(1, "What is Java?", "Programming Language", "Database", "Operating System", "IDE", "1", 1),
	            new Questions(2, "Who created Java?", "Microsoft", "Sun Microsystems", "Apple", "Google", "2", 1),
	            new Questions(3, "What is JVM?", "Java Virtual Machine", "Java Version Manager", "Java Video Module", "None", "1", 1),
	            new Questions(4, "Which keyword is used to create an object?", "create", "new", "object", "instantiate", "2", 1),
	            new Questions(5, "Which of the following is not a Java primitive type?", "int", "string", "boolean", "char", "2", 1)
	        };
	 
	 // HTML questions Array
	 Questions[] htmlQuestions = new Questions[]{
	            new Questions(1, "What does HTML stand for?", "Hyperlinks Text Markup Language", "Hyper Text Markup Language", "Hyper Transfer Markup Language", "Hyperlink and Text Modeling Language", "2", 1),
	            new Questions(2, "Which tag is used for inserting an image?", "<image>", "<img>", "<pic>", "<photo>", "2", 1),
	            new Questions(3, "Which tag is used to create a hyperlink?", "<link>", "<a>", "<url>", "<hyper>", "2", 1),
	            new Questions(4, "HTML is a subset of?", "SGML", "XML", "XHTML", "DHTML", "1", 1),
	            new Questions(5, "Which tag is used to make text bold?", "<bold>", "<strong>", "<b>", "<text>", "3", 1)
	        };
	 
	 
	 //Conduct Exam
	 public void conductExam(int ch)
	{
		 Scanner sc = new Scanner(System.in);
		if(ch==1)
		{	cnt++;
			System.out.println("Enter the Name :");
			String name = sc.next();
			Exam e = new Exam(cnt,name,"Java",new Date(),javaQuestions);
			int score = 0;
			for(int i = 0; i<e.getQuestion().length; i++) {
				System.out.println("Q"+ (i+1) +". "+ e.getQuestion()[i].getQuestion());
				System.out.println("Options are Below :");
				System.out.println(1 +". "+ e.getQuestion()[i].getOpt1());
				System.out.println(2 +". "+ e.getQuestion()[i].getOpt2());
				System.out.println(3 +". "+ e.getQuestion()[i].getOpt3());
				System.out.println(4 +". "+ e.getQuestion()[i].getOpt4());
				
				System.out.println("Your Option :");
				String ans = sc.next();
				
				if(ans.equals(e.getQuestion()[i].getAns()))
				{
					score += e.getQuestion()[i].getMarks();
				}
				
			}
			
			if(score >= 3) {
				System.out.println("your are pass");
				System.out.println("Your score is : "+score);
			}else {
				System.out.println("your are fail");
				System.out.println("Your score is : "+score);
			}
		}
		
		
		else
		{
			cnt++;
			System.out.println("Enter the Name :");
			String name = sc.next();
			Exam e = new Exam(cnt,name,"Html",new Date(),htmlQuestions);
			
			int score = 0;
			for(int i = 0; i<e.getQuestion().length; i++) {
				System.out.println("Q"+ (i+1) +". "+ e.getQuestion()[i].getQuestion());
				System.out.println("Options are Below :");
				System.out.println(1 +". "+ e.getQuestion()[i].getOpt1());
				System.out.println(2 +". "+ e.getQuestion()[i].getOpt2());
				System.out.println(3 +". "+ e.getQuestion()[i].getOpt3());
				System.out.println(4 +". "+ e.getQuestion()[i].getOpt4());
				
				System.out.println("Your Option :");
				String ans = sc.next();
				
				if(ans.equalsIgnoreCase(e.getQuestion()[i].getAns()))
				{
					score += e.getQuestion()[i].getMarks();
				}
				
			}
			
			if(score >= 3) {
				System.out.println("your are pass");
				System.out.println("Your score is : "+score);
			}else {
				System.out.println("your are fail");
				System.out.println("Your score is : "+score);
			}
		}
	}
}
