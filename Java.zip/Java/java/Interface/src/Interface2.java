
public interface Interface2 {

	public static void m3()
	{
		System.out.println("in m3");
	}
	
	public void m4();
	

}
