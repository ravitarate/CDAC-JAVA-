
public interface Interface1 {

	void m1();
	
	void m2();
	
}
