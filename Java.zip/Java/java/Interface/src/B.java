
public class B 
{
	public static void main(String[] args) {
		Interface1 i = new A();
		i.m1();
		i.m2();
		((A)i).m4();
		Interface2.m3();
		
	}
	
}
