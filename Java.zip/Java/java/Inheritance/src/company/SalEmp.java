package company;
import java.util.Date;
public class SalEmp extends Employee {
	private double sal;
	private double bouns;
	SalEmp(){
		super();
		this.sal = 0;
		this.bouns = 0;
	}
	public SalEmp(String name, String mobNo,Date dob, String dept, String desg, double sal) {
		super("s",name,mobNo,dob,dept,desg);
		this.sal = sal;
		this.bouns = this.sal * 0.010;
	}
	public double getSal() {
		return sal;
	}
	public double getBouns() {
		return bouns;
	}
	public void setSal(double sal) {
		this.sal = sal;
	}
	public void setBouns(double bouns) {
		this.bouns = bouns;
	}
	
	@Override
	public String toString() {
		return super.toString()+"\nSalEmp [sal=" + sal + ", bouns=" + bouns + "]";
	}
	
	
}
