package company;
import java.util.Date;
public class Employee  extends Person{
	private String dept;
	private String desg;
	
	Employee(){
		super();
		this.dept = null;
		this.desg = null;
	}
	
	Employee(String type ,String name, String mobNo, Date dob,String dept, String desg){
		super(type,name,mobNo,dob);
		this.dept = dept;
		this.desg = desg;
	}
	public String getDept() {
		return dept;
	}
	public String getDesg() {
		return desg;
	}
	public void setDept(String dept) {
		this.dept = dept;
	}
	public void setDesg(String desg) {
		this.desg = desg;
	}
	@Override
	public String toString() {
		return super.toString()+"\nEmployee [dept=" + dept + ", desg=" + desg + "]";
	}
	
}
