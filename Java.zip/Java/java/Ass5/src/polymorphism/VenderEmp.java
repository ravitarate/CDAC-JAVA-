package polymorphism;

import java.util.Date;

public class VenderEmp extends Emp{
	private int noEmp;
	private double amount;
	
	public VenderEmp() {
		super();
	}
	
	public VenderEmp(String name, String mob,String email, Date date, String dept, String desc,int noEmp, double amount) {
		super("V", name, mob,email, date, dept, desc);
		this.noEmp = noEmp;
		this.amount = amount;
	}
	
	public int getNoEmp() {
		return noEmp;
	}
	public double getAmount() {
		return amount;
	}
	public void setNoEmp(int noEmp) {
		this.noEmp = noEmp;
	}
	public void setAmount(double amount) {
		this.amount = amount;
	}
	
	public double calSalary()
	{
		return amount+amount*0.18;
	}
	
	@Override
	public String toString() {
		return super.toString()+"VenderEmp [noEmp=" + noEmp + ", amount=" + amount + "]";
	}
	
	

}
