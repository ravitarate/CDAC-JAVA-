package polymorphism;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.Scanner;

public class EmployeeService {
	
	public static Emp[] emp = new Emp[50];
	public static int cnt;
	static {
		emp[0] = new SalariedEmp("Kavita","25545244","jsdjsg@gmail.com",new Date(), "Hr","mgr",34252); 
		emp[1] = new SalariedEmp("Ram","2145454","jsdjsg@gmail.com",new Date(), "Admin","mgr",30000);
		emp[2] = new ContractEmp("Rajesh","24545643","jsdjsg@gmail.com",new Date(), "hr","mgr",20, 1000);
		emp[3] = new ContractEmp("Ramesh","23536686","jfgdfgsg@gmail.com",new Date(), "Sales","mgr",15, 2000);
		emp[4] = new VenderEmp("Rupesh","24545643","dfdgg@gmail.com",new Date(), "sales","mgr",20, 1000);
		emp[5] = new VenderEmp("Suresh","23536686","fgdfgfg@gmail.com",new Date(), "hr","mgr",15, 2000);
		cnt=6;
	}
	
	// Accept Details
	
	public static void acceptEmp(int ch)
	{
		Scanner sc = new Scanner(System.in);
		
		System.out.println("Enter the Name :");
		String name = sc.next();
		System.out.println("Enter mob :");
		String mob = sc.next();
		System.out.println("Enter Email :");
		String email = sc.next();
		System.out.println("Enter department :");
		String dept = sc.next();
		System.out.println("Enter Designation :");
		String desg = sc.next();
		
		System.out.println("enetr date(dd/mm/yyyy)");
		String date=sc.next();
		
		SimpleDateFormat sdf=new SimpleDateFormat("dd/mm/yyyy");
		Date doj=null;
		try {
		   doj=sdf.parse(date);
		}catch(ParseException e) {
			e.printStackTrace();
		}
		
		if(ch == 1)
		{
			System.out.println("Enter the salary :");
			double sal = sc.nextDouble();
			emp[cnt] = new SalariedEmp(name,mob,email,doj,dept,desg,sal);
		}
		else {
			System.out.println("Enter hrs :");
			int hrs = sc.nextInt();
			System.out.println("Enter Charges :");
			double charges = sc.nextDouble();
			emp[cnt] = new ContractEmp(name, mob,email, doj, dept, desg,hrs,charges);
		}
		cnt++;
	}
	
	
	// Display Details
	
	public static void display()
	{
		for(int i=0; i<cnt;i++)
		{
			System.out.println(emp[i]);
		}
	}
	
	
	// Search by ID
	public static Emp findById(String id)
	{
		for(int i=0;i<cnt;i++)
		{
			if(emp[i].getId().equals(id))
			{
				return emp[i];
			}
		}
		return null;
	}
	
	// Search by Name
	
	public static Emp[] fingByName(String name)
	{
		Emp[] res =  new Emp[cnt];
		int idx = 0;
		for(int i = 0; i<cnt; i++) {
			if(emp[i].getName().toLowerCase().equals(name.toLowerCase())) {
				res[idx++] = emp[i];
			}
		}
		return res;
				
	}
	
	// Calculate the Salary
	
	public static double[] findByDesg(String desg) {
		double[] res = new double[cnt];
		int idx = 0;
		for(int i = 0; i<cnt; i++) {
			if(emp[i].getDesc().equalsIgnoreCase(desg)) {
				res[idx++] = emp[i].calSalary();
			}
		}
		return res;
	}
	
	
	// accept department from user and display 5 employees of that department.  
	
	public static Emp[] findByDept(String dept) {
		Emp[] res = new Emp[4];
		int idx = 0;
		for(int i = 0; i<5; i++) {
			if (emp[i] != null && emp[i].getDept() != null && emp[i].getDept().equalsIgnoreCase(dept)) {
			    res[idx++] = emp[i];
			}

		}
		return res;
	}

// Find Customer By type
	public static Emp[] findByType(String type) {
		
		Emp[] res = new Emp[cnt];
		int idx = 0;
		for(int i = 0; i<cnt; i++) {
			if(emp[i].getId().toLowerCase().charAt(0) == type.charAt(0)) {
				res[idx++] = emp[i];
			}

		}
		return res;
	}

}
