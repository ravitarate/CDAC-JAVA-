package polymorphism;

import java.util.Scanner;

public class TestEmp {

	public static void main(String[] args) {
		
		int choice=0;
		Scanner sc=new Scanner(System.in);
		do {
		System.out.println("1. Add new Employee");
		System.out.println("2. Display all");
		System.out.println("3. Find Emp By Id");
		System.out.println("4. Find Emp By Name");
		System.out.println("5. calculate salary and display for all emplyees with particular designation ");
		System.out.println("6.  accept department from user and display 5 employees of that department.  ");
		System.out.println("7.  Display All employees (ask user salaried/contract employee display only one type of emplyees based on selection) ");
		System.out.println("Enter the Choice :");
		choice=sc.nextInt();
		
		switch(choice)
		{
		
		case 1:
				System.out.println("1. SalariedEmp");
				System.out.println("2. ContractEmp");
				int ch=sc.nextInt();
				EmployeeService.acceptEmp(ch);
			break;
			
		case 2:
				EmployeeService.display();
			break;
			
		case 3:
			  System.out.println("Enter a Id");
			  String id = sc.next();
			  if(EmployeeService.findById(id) != null) {
				  System.out.println(EmployeeService.findById(id));
			  }else {
				  System.out.println("Employee not found");
			  }
			  break;
			  
		case 4: 
			  System.out.println("Enter a Name");
			  String name = sc.next();
			  for(int i = 0; i<EmployeeService.fingByName(name).length; i++) {
				  if(EmployeeService.fingByName(name)[i] != null) {
					  System.out.println(EmployeeService.fingByName(name)[i]);
				  }
			  }
			  break;
		case 5: 
			  System.out.println("Enter a desg");
			  String desg = sc.next();
			  for(int i = 0; i<EmployeeService.findByDesg(desg).length; i++) {
				  if(EmployeeService.findByDesg(desg)[i] != 0) {
					  System.out.println(EmployeeService.findByDesg(desg)[i]);
				  }
			  }
			  break;	
			  
		case 6: 
			  System.out.println("Enter a dept");
			  String dept = sc.next();
			  Emp a[] = EmployeeService.findByDept(dept);
			  for(int i = 0; i<a.length; i++) {
				  if(a[i] != null) {
					  System.out.println(a[i]);
				  }
			  }
			  break;
		case 7: 
			  System.out.println("Enter a Type");
			  String type = sc.next();
			  Emp b[] = EmployeeService.findByType(type);
			  for(int i = 0; i<b.length; i++) {
				  if(b[i] != null) {
					  System.out.println(b[i]);
				  }
			  }
			  break;  
		case 8:
			sc.close();
			System.out.println("Exit.....");
		
		default: 
			System.out.println("You enter wrong Case");
				break;
		}

	}while(choice!=8);

}
}
