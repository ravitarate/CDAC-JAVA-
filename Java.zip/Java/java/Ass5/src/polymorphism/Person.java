package polymorphism;

import java.util.Date;

public class Person {
	private String id;
	private String name;
	private String mob,email;
	private Date doj;
	
	static int cnt = 0;
	
	public Person() {
		super();
	}
	public Person(String type, String name, String mob, String email, Date date) {
		super();
		this.id = generateId(type);
		this.name = name;
		this.mob = mob;
		this.email = email;
		this.doj = date;
	}
	private String generateId(String type) {
		cnt++;
		return type+cnt;
	}
	public String getId() {
		return id;
	}
	public String getName() {
		return name;
	}
	public String getMob() {
		return mob;
	}
	
	public void setName(String name) {
		this.name = name;
	}
	public void setMob(String mob) {
		this.mob = mob;
	}
	
	public String getEmail() {
		return email;
	}
	public Date getDoj() {
		return doj;
	}
	public void setEmail(String email) {
		this.email = email;
	}
	public void setDoj(Date doj) {
		this.doj = doj;
	}
	@Override
	public String toString() {
		return "Person [id=" + id + ", name=" + name + ", mob=" + mob + ", email=" + email + ", doj=" + doj + "]";
	}
	
	
	

}
