package polymorphism;

import java.util.Date;

public abstract class Emp extends Person{
	private String dept;
	private String desc;
	public Emp() {
		super();
		this.dept = null;
		this.desc = null;
	}
	public Emp(String type, String name, String mob,String email, Date date, String dept, String desc) {
		super(type, name, mob,email,date);
		this.dept = dept;
		this.desc = desc;
	}
	public String getDept() {
		return dept;
	}
	public String getDesc() {
		return desc;
	}
	public void setDept(String dept) {
		this.dept = dept;
	}
	public void setDesc(String desc) {
		this.desc = desc;
	}
	
	public abstract double calSalary();
	@Override
	public String toString() {
		return super.toString()+"Emp [dept=" + dept + ", desc=" + desc + "]";
	}
	
	
	
	
	

}
