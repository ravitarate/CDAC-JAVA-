
public class Friend {
	private int fid;
	private String name;
	private String mob;
	public Friend() {
		this.fid = 0;
		this.name = null;
		this.mob = null;
	}


	public Friend(int fid, String name, String mob) {
		this.fid = fid;
		this.name = name;
		this.mob = mob;
	}
	
	public int getFid() {
		return fid;
	}
	public String getName() {
		return name;
	}
	public String getMob() {
		return mob;
	}
	
	
	public void setName(String name) {
		this.name = name;
	}
	public void setMob(String mob) {
		this.mob = mob;
	}
	
	@Override
	public String toString() {
		return "Friend [fid=" + fid + ", Name=" + name + ", mob=" + mob + "]";
	}
	
	

}
