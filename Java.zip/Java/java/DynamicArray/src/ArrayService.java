import java.util.Scanner;

public class ArrayService {
	
	public static void AcceptArray(int[][] arr)
	{
		Scanner sc = new Scanner(System.in);
		
		for(int i=0;i<arr.length;i++)
		{
			System.out.println("Enter the col size :");
			int col=sc.nextInt();
			arr[i]=new int[col];
			 for(int j=0;j<col;j++)
			 {
				 System.out.println("Enter the row "+i+" and col "+j);
				 arr[i][j]= sc.nextInt();
			 }
		}
		sc.close();
	}
	
	public static void Display(int[][] arr)
	{
		for(int i=0;i<arr.length;i++)
		{
			for(int j=0;j<arr[i].length;j++)
			{
				System.out.print(arr[i][j]+ "\t");
			}
			System.out.println();
		}
		
	}

}
