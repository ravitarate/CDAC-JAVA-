package demo.Emp.Service;

import java.util.List;
import java.util.Map;
import java.util.Set;

import demo.Emp.Entity.Emp;

public interface EmpService {

	boolean addEmp();

	Set<Emp> displayAll();

	Emp findById(int id);

	List<Emp> findByName(String name);

	boolean deleteEmp(int id);

	boolean updateBySal(int id, double sal);

	List<Emp> sortByName();

	Set<Emp> sortById();

	List<Emp> sortBySal();

	Map<Integer, Emp> storeInTreeMap();

}
