
public class ABCTelTest {
	public static void main(String[] args) {
		Person V1 = new Vendor("Mukesh","jkdf@gmail.com","456464",new String[] {"iPhone","Mac book","Tv"});
		System.out.println(V1);
		
		Person indival = new IndividualCustomer("John Doe","john.doe@email.com","A",10.5,"Premium","1234567890");
		System.out.println(indival);
		
		Person company = new CompanyCustomer("Tech Corp","contact@techcorp.com", "B",  15.0,"Enterprise","Jane Smith",50000.0,new String[]{"101", "102"}, 
			    new String[]{"9876543211", "9876543212"});
		System.out.println(company);
	}
}
