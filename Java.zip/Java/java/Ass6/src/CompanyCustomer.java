import java.util.Arrays;

public class CompanyCustomer extends Customer{
	private String RM; 
	private double credit_line;
	private String[] extensions;
	private String[] numbers;
	public CompanyCustomer() {
		super();
	}
	
	public CompanyCustomer(String name, String email,String creditClass, double discounts, String planAssigned,String RM, double credit_line, String[] extensions, String[] numbers) {
		super("CC",name,email,creditClass,discounts,planAssigned);
		this.RM = RM;
		this.credit_line = credit_line;
		this.extensions = extensions;
		this.numbers = numbers;
	}
	public String getRM() {
		return RM;
	}
	public double getCredit_line() {
		return credit_line;
	}
	public String[] getExtensions() {
		return extensions;
	}
	public String[] getNumbers() {
		return numbers;
	}
	public void setRM(String rM) {
		RM = rM;
	}
	public void setCredit_line(double credit_line) {
		this.credit_line = credit_line;
	}
	public void setExtensions(String[] extensions) {
		this.extensions = extensions;
	}
	public void setNumbers(String[] numbers) {
		this.numbers = numbers;
	}

	@Override
	public String toString() {
		return super.toString()+"CompanyCustomer [RM=" + RM + ", credit_line=" + credit_line + ", extensions="
				+ Arrays.toString(extensions) + ", numbers=" + Arrays.toString(numbers) + "]";
	}
	
}
