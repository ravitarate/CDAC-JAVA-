
public class Customer extends Person{
    private String creditClass;
    private double discounts;
    private String planAssigned;
    
	public Customer() {
		super();
		this.creditClass = null;
		this.discounts = 0;
		this.planAssigned = null;
	}
	
	public Customer(String type,String name, String email,String creditClass, double discounts, String planAssigned) {
		super(type,name,email);
		this.creditClass = creditClass;
		this.discounts = discounts;
		this.planAssigned = planAssigned;
	}
	
	public String getCreditClass() {
		return creditClass;
	}
	public double getDiscounts() {
		return discounts;
	}
	public String getPlanAssigned() {
		return planAssigned;
	}
	
	public void setCreditClass(String creditClass) {
		this.creditClass = creditClass;
	}
	public void setDiscounts(double discounts) {
		this.discounts = discounts;
	}
	public void setPlanAssigned(String planAssigned) {
		this.planAssigned = planAssigned;
	}
	
	@Override
	public String toString() {
		return super.toString()+"Customer [creditClass=" + creditClass + ", discounts=" + discounts + ", planAssigned=" + planAssigned
				+ "]";
	}
	
}
