package com.team.Service;

public interface TeamService {

	void acceptTeam();

	boolean removeTeam(int tid);

	boolean removePlayer(int tid, int pid);

	void displayTeam();

	void displayBatsman(int tid);

	void displaySpeciality(int tid, String sp);

	boolean addPlayer(int tid);

	boolean modifyCoach(int tid, String name);

}
