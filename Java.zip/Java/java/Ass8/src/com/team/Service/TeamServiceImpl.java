package com.team.Service;
import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;

import com.team.Entity.Player;
import com.team.Dao.TeamDao;
import com.team.Dao.TeamDaoImpl;
import com.team.Entity.Team;

public class TeamServiceImpl implements TeamService{
	static TeamDao tdao ;
	public TeamServiceImpl() {
		tdao = new TeamDaoImpl();
	}
	@Override
	public void acceptTeam() {
		Scanner sc = new Scanner(System.in);
		Team t;
		System.out.println("Enter team id:");
		int tid = sc.nextInt();
		System.out.println("Enter the Team Name :");
		String name = sc.nextLine();
		System.out.println("Enter the Team Coachname :");
		String cname = sc.nextLine();
		sc.nextLine();
		
		List<Player> plist = new ArrayList<>();
		
		for(int i =1; i<=11; i++) {
				System.out.println("Enter the Player id :");
				int id=sc.nextInt();
				
	            System.out.println("Enter the Player Name :");
	            String pname = sc.nextLine();
	            
	            
	            System.out.println("Enter the Player Category :");
	            String cat = sc.nextLine();
	            
	     
	            plist.add(new Player(id,pname,cat));
		}
		
		t =new Team(tid, name, cname, plist);
		tdao.save(t);
		
	}
	@Override
	public boolean removeTeam(int tid) {
		return tdao.deleteTeam(tid);
	}
	@Override
	public boolean removePlayer(int tid, int pid) {
		return tdao.deletePlayer(tid,pid);
	}
	@Override
	public void displayTeam() {
		tdao.getTeam();
		
	}
	@Override
	public void displayBatsman(int tid) {
		tdao.findBatsman(tid);
		
	}
	@Override
	public void displaySpeciality(int tid, String sp) {
		tdao.showSprciality(tid,sp);
		
	}
	@Override
	public boolean addPlayer(int tid) {
		Scanner sc = new Scanner(System.in);
		
			System.out.println("Enter the Player id :");
			int id=sc.nextInt();
				
	        System.out.println("Enter the Player Name :");
	        String pname = sc.next();
	        System.out.println("Enter the Player Category :");
	        String cat = sc.next();
	 
	     return tdao.addPlayer(tid,new Player(id,pname,cat));
	           
		
	}
	@Override
	public boolean modifyCoach(int tid, String name) {
		return tdao.updateCoach(tid,name);
	}
	
	
}
