package Array;

import java.util.Scanner;

public class ArrayService {
	
	//Accept the array elements
	public static void accept(int arr[])
	{
		Scanner sc = new Scanner(System.in);
		for(int i=0;i<arr.length;i++)
		{
			arr[i] = sc.nextInt();
		}
	}
	
	//Accept the array elements
		public static void Display(int arr[])
		{
			for(int i=0;i<arr.length;i++)
			{
				System.out.println(arr[i]);
			}
		}
	
	//max element
	public static void maxElement(int arr[])
	{
		int max = 0;
		for(int i=0;i<arr.length;i++)
		{
			if(max < arr[i]) {
				max = arr[i];
			}
		}
		System.out.println("Max Element is :"+max);
	}
	
	//min element
		public static void minElement(int arr[])
		{
			int min = arr[0];
			for(int i=1;i<arr.length;i++)
			{
				if(min > arr[i]) {
					min = arr[i];
				}
			}
			System.out.println("Min Element is :"+min);
		}
		
		
	// Addition of Array
		public static void addArray(int arr[])
		{
			int sum =0;
			for(int i=0;i<arr.length;i++)
			{
				sum+=arr[i];
			}
			System.out.println("Addition of Array :"+sum);
		}
		
	
		// Addition of prime Numbers
				public static void addPrime(int arr[])
				{
					int sum =0;
					for(int i=0;i<arr.length;i++)
					{
						if(isPrime(arr[i])) {
							sum += arr[i];
						}
					}
					System.out.println("Addition Prime Number in Array :"+sum);
				}
				
				public static boolean isPrime(int n)
				{
					for(int i=2;i<n-1;i++)
					{
						if(n%i ==0) {
							return false;
						}
					}
					return true;
				}
				

}
