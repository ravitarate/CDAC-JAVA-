package com.thread.Test;

import com.thread.demo.ThreadAdd;
import com.thread.demo.ThreadMulti;
import com.thread.entity.MyClass;

public class TestSynchronize {

	public static void main(String[] args) {
		MyClass mc = new MyClass();
		
		ThreadAdd ta = new ThreadAdd(mc);
		ta.start();
		ThreadMulti tm = new ThreadMulti(mc);
		tm.start();
	}

}
