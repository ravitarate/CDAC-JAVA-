package com.thread.entity;

public class MyClass {
	private int n;
	private boolean flag;
	
	public MyClass() {
		super();
		this.n = 0;
		this.flag = false;
	}

	synchronized public void add(int a) {
		if(flag) {
			try {
				wait();
			} catch (InterruptedException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}
		n = a;
		flag = true;
		System.out.println("add :"+n);
		notify();
	}
	
	synchronized public void multiplication(int a) {
		if(!flag) {
			try {
				wait();
			} catch (InterruptedException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}
		
		System.out.println("Mul :"+n);
		flag = false;
		notify();
	}
}
