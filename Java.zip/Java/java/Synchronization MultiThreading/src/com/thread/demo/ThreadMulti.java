package com.thread.demo;

import com.thread.entity.MyClass;

public class ThreadMulti extends Thread{
		private MyClass mc;
	
		
	
		public ThreadMulti(MyClass mc) {
			super();
			this.mc = mc;
		}
	
	
		public void run()
		{
			for(int i =1;i<9;i++)
			{
				mc.multiplication(i);
			}
		}

}
