package com.thread.demo;

import com.thread.entity.FindWord;

public class SearchThread extends Thread {
	private FindWord fw;
	private String str;
	public SearchThread(FindWord fw, String str) {
		super();
		this.fw = fw;
		this.str = str;
	}
	public void run() {
		fw.search(str);
	}
	
}
