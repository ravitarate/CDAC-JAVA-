package com.emp.entity;

import java.util.Date;

public class SalariedEmp extends Emp {
	private double sal;
	private double bonus;
	public SalariedEmp() {
		super();
		this.sal = 0;
		this.bonus = 0;
	}
	public SalariedEmp(int id, String name, String mob, String email, Date doj, String dept, String desc,double sal) {
		super(id,name, mob, email, doj,dept,desc);
		this.sal = sal;
		this.bonus = sal*0.15;
	}

	public double getSal() {
		return sal;
	}
	public double getBonus() {
		return bonus;
	}
	public void setSal(double sal) {
		this.sal = sal;
	}
	public void setBonus(double bonus) {
		this.bonus = bonus;
	}
	@Override
	public String toString() {
		return super.toString()+"SalariedEmp [sal=" + sal + ", bonus=" + bonus + "]";
	}
	

}
