package com.emp.entity;

import java.util.Date;

public class ContractEmp extends Emp {
	private int hrs;
	private double charges;
	public ContractEmp() {
		super();
		this.hrs = 0;
		this.charges = 0;
	}
	public ContractEmp(int id, String name, String mob, String email, Date doj, String dept, String desc, int hrs, double charges) {
		super(id,name, mob, email, doj,dept,desc);
		this.hrs = hrs;
		this.charges = charges;
	}
	
	public int getHrs() {
		return hrs;
	}
	public double getCharges() {
		return charges;
	}
	public void setHrs(int hrs) {
		this.hrs = hrs;
	}
	public void setCharges(double charges) {
		this.charges = charges;
	}
	@Override
	public String toString() {
		return super.toString()+"ContractEmp [hrs=" + hrs + ", charges=" + charges + "]";
	}
	

}
