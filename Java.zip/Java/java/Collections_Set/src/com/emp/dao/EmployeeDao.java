package com.emp.dao;

import java.util.List;
import java.util.Set;

import com.emp.entity.Emp;

public interface EmployeeDao {

	boolean save(Emp e);

	Set<Emp> displayEmployee();

	Emp findByID(int id);

	List<Emp> findByName(String name);

	boolean removeById(int id);

	boolean updateName(int id, String name);

	List<Emp> sortByName();

	Set<Emp> sortByID();

	List<Emp> orderBySal();


}
