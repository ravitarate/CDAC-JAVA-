package com.emp.services;

import java.util.List;
import java.util.Set;

import com.emp.entity.Emp;

public interface EmployeeService {

	boolean addEmployee(int c);

	Set<Emp> displayEmp();

	Emp findById(int id);

	List<Emp> findByName(String name);

	boolean deleteById(int id);

	boolean modifyByName(int id, String name);

	List<Emp> sortByName();

	Set<Emp> sortById();

	List<Emp> sortBySal();

}
