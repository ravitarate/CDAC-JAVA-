package com.emp.services;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.HashSet;
import java.util.List;
import java.util.Scanner;
import java.util.Set;

import com.emp.dao.EmployeeDao;
import com.emp.dao.EmployeeDaoImpl;
import com.emp.entity.ContractEmp;
import com.emp.entity.Emp;
import com.emp.entity.SalariedEmp;

public class EmployeeSerivceImpl implements EmployeeService{
	EmployeeDao edao = new EmployeeDaoImpl();

	@Override
	public boolean addEmployee(int c) {
		Scanner sc = new Scanner(System.in);
		
		System.out.println("Enter id :");
		int id = sc.nextInt();
		System.out.println("Enter Name :");
		String name = sc.next();
		System.out.println("Enter Mobile Number :");
		String mob = sc.next();
		System.out.println("Enter the Email :");
		String mail = sc.next();
		
		System.out.println("Enter Date of joining (dd/mm/yyyy) :");
		String dt = sc.next();
		SimpleDateFormat date = new SimpleDateFormat("dd/mm/yyyy");
		Date doj = null;
		try {
			doj = date.parse(dt);
		}
		catch(ParseException e) {
			e.printStackTrace();
		}
		
		System.out.println("Enter the Department :");
		String dept = sc.next();
		System.out.println("Enter the Designation :");
		String desg = sc.next();
		
		Emp e = null;
		if(c==1)
		{
			System.out.println("Enter your Salary :");
			double sal = sc.nextDouble();
			e = new SalariedEmp(id,name, mob, mail, doj, dept, desg, sal);
		}
		else
		{
			System.out.println("Enter the number of hrs :");
			int hr = sc.nextInt();
			System.out.println("Enter the charges :");
			double charges = sc.nextDouble();
			e = new ContractEmp(id,name, mob, mail, doj, dept, desg, hr, charges);
		}
		
		return edao.save(e);

	}

	@Override
	public Set<Emp> displayEmp() {
		return edao.displayEmployee();
	}

	@Override
	public Emp findById(int id) {
		return edao.findByID(id);
	}

	@Override
	public List<Emp> findByName(String name) {

		return edao.findByName(name);
	}

	@Override
	public boolean deleteById(int id) {
		return edao.removeById(id);
	}

	@Override
	public boolean modifyByName(int id, String name) {
		return edao.updateName(id,name);
	}

	@Override
	public List<Emp> sortByName() {
		return edao.sortByName();
	}

	@Override
	public Set<Emp> sortById() {
		return edao.sortByID();
	}

	@Override
	public List<Emp> sortBySal() {
		// TODO Auto-generated method stub
		return edao.orderBySal();
	}
	
}
