package com.emp.test;


import java.util.List;
import java.util.Scanner;
import java.util.Set;

import com.emp.entity.Emp;
import com.emp.services.EmployeeSerivceImpl;
import com.emp.services.EmployeeService;

public class TestEmployee {
	public static void main(String[] args) {
		EmployeeService es = new EmployeeSerivceImpl();
		Scanner sc = new Scanner(System.in);
		int ch;
		do {
			System.out.println();
			System.err.println("1. Adding the new Employees");
			System.err.println("2. Display the Employees");
			System.err.println("3. Find Employee By ID");
			System.err.println("4. Find Employee By Name");
			System.err.println("5. Delete Employees");
			System.err.println("6. Modify Employee");
			System.err.println("7. display in sorted order by name");
			System.err.println("8. Display in sorted order by id");
			System.err.println("9. Display in sorted order by sal");
			System.err.println("10. Exit");
			System.err.println("Enter Your Choice :");
			ch = sc.nextInt();
			
			switch (ch) {
			
			case 1:
					System.out.println("1.Salaried Employee\n2.Contract Employee\n which Employee");
					int c = sc.nextInt();
					boolean flag = es.addEmployee(c);
					if(flag) {
						System.out.println("Added Employee");
					}else {
						System.out.println("Duplicate Entry");
					}
				break;
				
			case 2:
				Set<Emp> el = es.displayEmp();
				el.forEach(System.out::println);
				break;
				
			case 3:
				System.out.println("Enter the id");
				int id = sc.nextInt();
				Emp e = es.findById(id);
				if(e != null) {
					System.out.println(e);
				}else {
					System.out.println("Not found");
				}
				break;
				
			case 4:
				System.out.println("Enter the Name :");
				String name = sc.next();
				List<Emp> elist = es.findByName(name);
				elist.forEach(System.out::println);
				break;
				
			case 5:
				System.out.println("Enter the id");
				id = sc.nextInt();
				flag = es.deleteById(id);
				if(flag) {
					System.out.println("Deleted");
				}else {
					System.out.println("Not found");
				}
				break;
				
			case 6:
				System.out.println("Enter the id");
				id = sc.nextInt();
				System.out.println("Enter the Name :");
				name = sc.next();
				flag = es.modifyByName(id,name);
				if(flag) {
					System.out.println("Name is updated");
				}else {
					System.out.println("Not found");
				}
				break;
				
			case 7:
				elist = es.sortByName();
				elist.forEach(System.out::println);
				break;
			
			case 8:
				Set<Emp> set = es.sortById();
				set.forEach(System.out::println);
				break;
				
			case 9:
				elist = es.sortBySal();
				elist.forEach(System.out::println);
				break;
				
			case 10:
				sc.close();
				System.out.println("Thank you");
				break;

			default:
				System.out.println("wrong choice");
				break;
			}
			
		}while(ch!=10);
	}

}
