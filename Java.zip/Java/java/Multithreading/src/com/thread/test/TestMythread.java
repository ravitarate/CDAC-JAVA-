package com.thread.test;

import com.thread.mean.MyClass;
import com.thread.myclass.MyThreadClass;
import com.thread.myclass.ThreadPrime;
import com.thread.myclass.ThreadTable;

public class TestMythread {

	public static void main(String[] args) {
	MyClass obj = new MyClass();
	
	MyThreadClass th = new MyThreadClass(obj,5);
	ThreadPrime tp = new ThreadPrime(obj,6);
	ThreadTable tb = new ThreadTable(obj,4);
	th.start();
	tp.start();
	tb.start();
	}

}
