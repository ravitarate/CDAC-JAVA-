package com.thread.myclass;

import com.thread.mean.MyClass;

public class ThreadPrime  extends Thread{
	private MyClass obj;
	private int n;
	

	public ThreadPrime(MyClass obj, int n) {
		super();
		this.obj = obj;
		this.n = n;
	}


	public void run()
	{
		obj.isPrime(n);
	}

}
