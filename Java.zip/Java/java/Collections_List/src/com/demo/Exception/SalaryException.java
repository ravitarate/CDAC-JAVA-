package com.demo.Exception;

public class SalaryException extends Exception {
	public SalaryException(String msg) {
		super(msg);
	}

}
