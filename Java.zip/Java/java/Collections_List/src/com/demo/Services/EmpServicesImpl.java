package com.demo.Services;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.List;
import java.util.Scanner;

import com.demo.DAO.EmpDAO;
import com.demo.DAO.EmpDAOImpl;
import com.demo.Entity.ContractEmp;
import com.demo.Entity.Emp;
import com.demo.Entity.SalariedEmp;
import com.demo.Exception.SalaryException;

public class EmpServicesImpl implements EmpServices{
	EmpDAO dao = new EmpDAOImpl();

	
	
	// Adding the Employees
	@Override
	public boolean addEmployees(int ch) throws SalaryException {
		try (Scanner sc = new Scanner(System.in)) {
			System.out.println("Enter Name :");
			String name = sc.next();
			System.out.println("Enter Mobile Number :");
			String mob = sc.next();
			System.out.println("Enter the Email :");
			String mail = sc.next();
			
			System.out.println("Enter Date of joining (dd/mm/yyyy) :");
			String dt = sc.next();
			SimpleDateFormat date = new SimpleDateFormat("dd/mm/yyyy");
			Date doj = null;
			try {
				doj = date.parse(dt);
			}
			catch(ParseException e) {
				e.printStackTrace();
			}
			
			System.out.println("Enter the Department :");
			String dept = sc.next();
			System.out.println("Enter the Designation :");
			String desg = sc.next();
			
			Emp e = null;
			if(ch==1)
			{
				try {
					System.out.println("Enter your Salary :");
					double sal = sc.nextDouble();
					if(sal<1000)
					{
						throw new SalaryException("Salary should be above 1000");
					}
					else {
						e = new SalariedEmp(name, mob, mail, doj, dept, desg, sal);
					}
					
				}catch(SalaryException t)
				{
					System.out.println(t.getMessage());
				}
				
			}
			else
			{
				try {
					System.out.println("Enter the number of hrs :");
					int hr = sc.nextInt();
					System.out.println("Enter the charges :");
					double charges = sc.nextDouble();
					if(charges<1000)
					{
						throw new SalaryException("charges should be above 1000");
					}
					else {
						e = new ContractEmp(name, mob, mail, doj, dept, desg, hr, charges);
					}
				}catch(SalaryException t)
				{
					System.out.println(t.getMessage());
				}
				
				
			}
			
			return dao.save(e);
		}
	}


	// Display All the Employees
	@Override
	public List<Emp> DisplayEmp() {
		return dao.findAll();
		
	}


	// Find Employee By ID
	@Override
	public Emp findById(String id) {
		return dao.getById(id);
	}


	//Find Employee By Name
	@Override
	public List<Emp> findByName(String name) {
		return dao.findByName(name);
	}

	// Delete the Employee
	@Override
	public boolean deleteEmp(String id) {
		return dao.deleteEmp(id);
	}

	// Modify the Name of Employee
	@Override
	public boolean modifyEmp(String id, String name) {
		return dao.updateName(id,name);
	}

	//sort by name
	@Override
	public List<Emp> sortByName() {
		return dao.sortByN();
	}

	//sort by ID
	@Override
	public List<Emp> sortById() {
		return dao.sortById();
	}
	
	
	
	
	
	

}
