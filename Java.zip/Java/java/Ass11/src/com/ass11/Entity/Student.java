package com.ass11.Entity;

import java.sql.Date;
import java.time.LocalDate;
import java.util.Objects;

public class Student {
	private int sid;
	private String name,degree;
	private LocalDate bdate;
	private double marks;
	public Student() {
		super();
	}
	public Student(int sid, String name, String degree, LocalDate bdate, double marks) {
		super();
		this.sid = sid;
		this.name = name;
		this.degree = degree;
		this.bdate = bdate;
		this.marks = marks;
	}
	public Student(int sid) {
		super();
		this.sid = sid;
	}
	
	public Student(String degree) {
		this.degree = degree;
	}
	public int getSid() {
		return sid;
	}
	public String getName() {
		return name;
	}
	public String getDegree() {
		return degree;
	}
	
	public double getMarks() {
		return marks;
	}
	public void setSid(int sid) {
		this.sid = sid;
	}
	public void setName(String name) {
		this.name = name;
	}
	public void setDegree(String degree) {
		this.degree = degree;
	}
	
	public void setMarks(double marks) {
		this.marks = marks;
	}
	
	public LocalDate getBdate() {
		return bdate;
	}
	public void setBdate(LocalDate bdate) {
		this.bdate = bdate;
	}
	@Override
	public String toString() {
		return "Student [sid=" + sid + ", name=" + name + ", degree=" + degree + ", bdate=" + bdate + ", marks=" + marks
				+ "]";
	}
	
	@Override
	public int hashCode() {
		return Objects.hash(sid);
	}
	@Override
	public boolean equals(Object obj) {
		Student other = (Student) obj;
		return sid == other.sid;
	}
	

}
