package com.ass11.Test;
import java.util.List;
import java.util.Scanner;
import com.ass11.Entity.Student;
import com.ass11.Service.StudentService;
import com.ass11.Service.StudentServiceImpl;

public class TestStudent {

	public static void main(String[] args) {
		Scanner sc = new Scanner(System.in);
		
		StudentService std = new StudentServiceImpl();
		
		int ch;
		  
		do {
			System.out.println();
			System.out.println("1. add new student");
			System.out.println("2. add new skill for a student ");
			System.out.println("3. delete student");
			System.out.println("4. delete skill for a student");
			System.out.println("5. display all students with given skill(accept skill from user)");
			System.out.println("6. display all students with given degree(accept degree from user");
			System.out.println("7. display All Student");
			System.out.println("8. Exit");
			System.out.println("Enter Your Choice :");
			ch = sc.nextInt();
			
			switch (ch) {
			
			case 1:
				boolean status = std.addStudent();
				if(status)
				{
					System.out.println("Added Successfully");
				}
				else {
					System.err.println("Duplicate Student");
				}
				break;
				
			case 2:
				System.out.println("Enter Student Id :");
				int id = sc.nextInt();
				System.out.println("Enter Number of Skills :");
				int cnt = sc.nextInt();
				status = std.addSSkills(id,cnt);
				if(status)
				{
					System.out.println("Added Successfully");
				}
				else {
					System.err.println("Duplicate Student");
				}
				
				break;
				
			case 3:
				System.out.println("Enter Student Id :");
				id = sc.nextInt();
				status = std.deleteStudent(id);
				if(status)
				{
					System.out.println("Deleted Successfully");
				}
				else {
					System.err.println("Student not found");
				}
				break;
				
			case 4:
				System.out.println("Enter Student Id :");
				id = sc.nextInt();
				System.out.println("Enter Student Skill to Remove :");
				String skill= sc.next();
				status = std.deleteSkill(id,skill);
				if(status)
				{
					System.out.println("Deleted Successfully");
				}
				else {
					System.err.println("Student not found");
				}
				break;
				
			case 5:
				System.out.println("Enter Student Skill ");
				skill= sc.next();
				List<Student> slist = std.getStudentBySkill(skill);
				if(!slist.isEmpty())
				{
					slist.forEach(System.out::println);
				}
				else {
					System.err.println("Skill not match");
				}
				break;
				
			case 6:
				System.out.println("Enter Student Degree ");
				String Degree= sc.next();
				slist = std.getStudentByDegree(Degree);
				if(!slist.isEmpty())
				{
					slist.forEach(System.out::println);
				}
				else {
					System.err.println("Degree not match");
				}
				break;
				
			case 7:
				std.displayAll();
				break;
					
			case 8:
				sc.close();
				System.out.println("Thank You........");
				break;
				
			default:
				System.out.println("You Entered Wrong Choice");
				break;
			}
		}while(ch!=8);

	}

}
