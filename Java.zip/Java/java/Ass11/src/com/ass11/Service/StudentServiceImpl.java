package com.ass11.Service;

import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import java.util.Date;
import java.util.HashSet;
import java.util.List;
import java.util.Scanner;
import java.util.Set;

import com.ass11.DAO.StudentDao;
import com.ass11.DAO.StudentDaoImlp;
import com.ass11.Entity.Student;
import com.ass11.Entity.StudentSkills;

public class StudentServiceImpl implements StudentService {
	
	static StudentDao sdao = new StudentDaoImlp();

	@Override
	public boolean addStudent() {
		Scanner sc = new Scanner(System.in);
		System.out.println("Enter Student Id :");
		int id = sc.nextInt();
		System.out.println("Enter Student Name :");
		String name = sc.next();
		System.out.println("Enter Student Degree :");
		String d = sc.next();
		System.out.println("Enter Student DOB (dd/mm/yyyy):");
		String dt = sc.next();
		LocalDate ldt = LocalDate.parse(dt,DateTimeFormatter.ofPattern("dd/MM/yyyy"));
		System.out.println("Enter Student Marks :");
		double marks = sc.nextDouble();
		
		Set<String> s = new HashSet<>();
		System.out.println("Enter Number of Skills :");
		int cnt = sc.nextInt();
		
		for(int i = 0; i<cnt; i++) {
			System.out.println("Enter Skill :"+(i+1));
			String skill = sc.next();
			s.add(skill);
			
		}
		
		return sdao.save(new Student(id, name, d, ldt, marks),new StudentSkills(s));
		
	}

	@Override
	public void displayAll() {
		
		sdao.findAll();
		
	}

	@Override
	public boolean addSSkills(int id, int cnt) {
		Set<String> s = new HashSet<>();
		Scanner sc = new Scanner(System.in);
		for(int i = 0; i<cnt; i++) {
			System.out.println("Enter Skill :"+(i+1));
			String skill = sc.next();
			s.add(skill);
			
		}
		return sdao.addSkill(id,s);
	}

	@Override
	public boolean deleteStudent(int id) {
		return sdao.removeStudent(id);
	}

	@Override
	public boolean deleteSkill(int id, String skill) {
		return sdao.reomveSkill(id,skill);
	}

	@Override
	public List<Student> getStudentBySkill(String skill) {
		return sdao.displayStudentBySkill(skill);
	}

	@Override
	public List<Student> getStudentByDegree(String degree) {
		return sdao.displayStudentByDegree(degree);
	}

	
	

}
