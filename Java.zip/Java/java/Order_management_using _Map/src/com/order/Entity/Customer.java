package com.order.Entity;

import java.util.Objects;

public class Customer {
	private int cid;
	private String cname;
	private String cmob;
	
	public Customer() {
		super();
	}
	
	public Customer(int cid) {
		this.cid = cid;
	}
	public Customer(int cid, String cname, String cmob) {
		super();
		this.cid = cid;
		this.cname = cname;
		this.cmob = cmob;
	}
	
	public int getCid() {
		return cid;
	}
	public String getCname() {
		return cname;
	}
	public String getCmob() {
		return cmob;
	}
	public void setCid(int cid) {
		this.cid = cid;
	}
	public void setCname(String cname) {
		this.cname = cname;
	}
	public void setCmob(String cmob) {
		this.cmob = cmob;
	}
	
	@Override
	public int hashCode() {
		return Objects.hash(cid);
	}

	@Override
	public boolean equals(Object obj) {
		
		Customer other = (Customer) obj;
		return cid == other.cid;
	}

	@Override
	public String toString() {
		return "Customer [cid=" + cid + ", cname=" + cname + ", cmob=" + cmob + "]";
	}
	
	
}
