package com.order.Entity;

import java.time.LocalDate;
import java.util.Objects;

public class Item {
	private int itemno;
	private String iname;
	private int qty;
	private double price;
	private LocalDate mfgdate;
	
	public Item() {
		super();
	}
	public Item(int itemno) {
		this.itemno = itemno;
	}
	
	public Item(int itemno, String iname, int qty, double price, LocalDate mfgdate) {
		super();
		this.itemno = itemno;
		this.iname = iname;
		this.qty = qty;
		this.price = price;
		this.mfgdate = mfgdate;
	}
	
	public int getItemno() {
		return itemno;
	}
	public String getIname() {
		return iname;
	}
	public int getQty() {
		return qty;
	}
	public double getPrice() {
		return price;
	}
	public LocalDate getMfgdate() {
		return mfgdate;
	}
	public void setItemno(int itemno) {
		this.itemno = itemno;
	}
	public void setIname(String iname) {
		this.iname = iname;
	}
	public void setQty(int qty) {
		this.qty = qty;
	}
	public void setPrice(double price) {
		this.price = price;
	}
	public void setMfgdate(LocalDate mfgdate) {
		this.mfgdate = mfgdate;
	}
	
	public double Total() {
		return this.price * this.qty;
	}
	
	@Override
	public String toString() {
		return "Item [itemno=" + itemno + ", iname=" + iname + ", qty=" + qty + ", price=" + price + ", mfgdate="
				+ mfgdate + "]";
	}
	@Override
	public int hashCode() {
		return Objects.hash(itemno);
	}
	@Override
	public boolean equals(Object obj) {
	
		Item other = (Item) obj;
		return itemno == other.itemno;
	}
	
	
	
	
	
	

}
