package com.order.Service;

import java.util.List;
import java.util.Map;

import com.order.Entity.Customer;
import com.order.Entity.Item;

public interface OrderService {

	boolean addNewOrder();

	Map<Customer, List<Item>> showAll();

	boolean deleteOrder(int cid);

	boolean modifyMob(int cid, String mob);

	boolean addItem(int cid);

	boolean modfiyQty(int cid, int qty, int qty2);

	boolean deleteItem(int cid, int iid);

	List<Item> listOfOrder(int cid);

	List<Item> listOfItemByName(int cid, String itemn);

	double OrderAmt(int cid);
	

}
