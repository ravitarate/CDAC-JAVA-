package com.order.Service;

import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import java.util.ArrayList;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import java.util.Scanner;

import com.order.Dao.OrderDao;
import com.order.Dao.OrderDaoImpl;
import com.order.Entity.Customer;
import com.order.Entity.Item;

public class OrderServiceImpl implements OrderService {
	static OrderDao odao;
	static {
		odao = new OrderDaoImpl();
	}
	//To Accept the Order
	@Override
	public boolean addNewOrder() {
		Scanner sc = new Scanner(System.in);
		
		System.out.println("Enter the Id:");
		int id = sc.nextInt();
		System.out.println("Enter a name :");
		String name = sc.next();
		System.out.println("Enter a Mobile Number:");
		String mob = sc.next();
		Customer c = new Customer(id, name, mob);
		
		List<Item> ilst = new ArrayList<>();
		String order =null;
		
		do {
		System.out.println("Enter Order Id :");
		int iid = sc.nextInt();
		System.out.println("Enter item Name :");
		String iname = sc.next();
		System.out.println("Enter the Qty :");
		int qty = sc.nextInt();
		System.out.println("Enter the price :");
		double price = sc.nextDouble();
		System.out.println("Enter the mfg date (dd/mm/yyyy) :");
		String dt = sc.next();
		LocalDate ldt = LocalDate.parse(dt,DateTimeFormatter.ofPattern("dd/MM/yyyy"));
		
		ilst.add(new Item(iid, iname, qty, price, ldt));
		
		System.out.println("Do you want to add more order (y/n)");
		order=sc.next();
		return odao.save(c,ilst);
				
		}while(order.equals("y"));
		
	}
	
	//to Display the orders
	@Override
	public Map<Customer, List<Item>> showAll() {
		return odao.displayAll();
	}
	
	//To delete the Orders
	@Override
	public boolean deleteOrder(int cid) {
		return odao.removeOrderByID(cid);
	}
	
	//to modifiy the mobile number
	@Override
	public boolean modifyMob(int cid,String mob) {
		
		return odao.updateMobile(cid,mob);
	}
	
	//to add new item in existing order
	@Override
	public boolean addItem(int cid) {
		Scanner sc = new Scanner(System.in);
		List<Item> ilst = new ArrayList<>();
		String order =null;
		
		do {
		System.out.println("Enter Order Id :");
		int iid = sc.nextInt();
		System.out.println("Enter item Name :");
		String iname = sc.next();
		System.out.println("Enter the Qty :");
		int qty = sc.nextInt();
		System.out.println("Enter the price :");
		double price = sc.nextDouble();
		System.out.println("Enter the mfg date (dd/mm/yyyy) :");
		String dt = sc.next();
		LocalDate ldt = LocalDate.parse(dt,DateTimeFormatter.ofPattern("dd/MM/yyyy"));
		
		ilst.add(new Item(iid, iname, qty, price, ldt));
		
		System.out.println("Do you want to add more order (y/n)");
		order=sc.next();
		
				
		}while(order.equals("y"));
		return odao.addItems(cid,ilst);
	}
	
	//to modfity the particular item quantity 
	@Override
	public boolean modfiyQty(int cid,int iid ,int qty) {
		return odao.updateQty(cid,iid,qty);
	}
	
	//to delete particular item
	@Override
	public boolean deleteItem(int cid, int iid) {
		return odao.removeItem(cid,iid);
	}
	
	//to display list of items
	@Override
	public List<Item> listOfOrder(int cid) {
		return odao.listOrder(cid);
	}
	
	//to display item by name
	@Override
	public List<Item> listOfItemByName(int cid,String itemn) {
		return odao.listByNameOfItem(cid,itemn);
	}
	//to display total amount of orders
	@Override
	public double OrderAmt(int cid) {
		return odao.totalAmtOfOrder(cid);
	}
	

}
