package com.order.Dao;

import java.util.List;
import java.util.Map;

import com.order.Entity.Customer;
import com.order.Entity.Item;

public interface OrderDao {

	boolean save(Customer c, List<Item> ilst);

	Map<Customer, List<Item>> displayAll();

	boolean removeOrderByID(int cid);

	boolean updateMobile(int cid, String mob);

	boolean addItems(int cid, List<Item> ilst);

	boolean updateQty(int cid, int qty, int qty2);

	boolean removeItem(int cid, int iid);

	List<Item> listOrder(int cid);

	List<Item> listByNameOfItem(int cid, String itemn);

	double totalAmtOfOrder(int cid);

	
}
