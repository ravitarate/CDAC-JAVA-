package com.order.Dao;

import java.time.LocalDate;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Set;

import com.order.Entity.Customer;
import com.order.Entity.Item;

public class OrderDaoImpl implements OrderDao {
	static Map<Customer, List<Item>> imap = new  HashMap<>();
	
	static {
		
		Customer c = new Customer(101,"Rajesh", "1234345234");
		List<Item> lst = new ArrayList<>();
		lst.add(new Item(100,"Bed",34,3456,LocalDate.of(2023, 11,10)));
		lst.add(new Item(101,"Table",10,5000,LocalDate.of(2024, 8,20)));
		imap.put(c, lst);
		
		
		Customer c1 = new Customer(102,"Dipesh", "23345436456");
		List<Item> lst1 = new ArrayList<>();
		lst1.add(new Item(100,"Bed",5,10000,LocalDate.of(2025, 12,13)));
		lst1.add(new Item(101,"Sofa",10,1500,LocalDate.of(2024, 9,20)));
		imap.put(c1, lst1);
		
		Customer c2 = new Customer(103,"Dipesh", "23345436456");
		List<Item> lst2 = new ArrayList<>();
		lst2.add(new Item(100,"Bed",5,10000,LocalDate.of(2025, 12,13)));
		lst2.add(new Item(101,"Sofa",10,1500,LocalDate.of(2024, 9,20)));
		imap.put(c2, lst2);
	}


	@Override
	public boolean save(Customer c, List<Item> ilst) {
		if(imap.containsKey(c))
		{
			imap.put(c, ilst);
			return true;
		}
		return false;
	}

	@Override
	public Map<Customer, List<Item>> displayAll() {
		return imap;
	}

	@Override
	public boolean removeOrderByID(int cid) {
		if(imap.remove(new Customer(cid)) == null) {
			return false;
		}
		return true;
		
//		Set<Customer> cset = imap.keySet();
//		
//		for(Customer c:cset) {
//			if(c.getCid() == cid) {
//				imap.remove(c);
//				return true;
//			}
//		}
//		return false;
	}

	@Override
	public boolean updateMobile(int cid, String mob) {
		Set<Customer> cset = imap.keySet();
		
		for(Customer c:cset) {
			if(c.getCid() == cid) {
				c.setCmob(mob);
				return true;
			}
		}
		return false;
		
	}

	@Override
	public boolean addItems(int cid, List<Item> ilst) {
		if(imap.containsKey(new Customer(cid))) {
			List<Item> list = imap.get(new Customer(cid));
			list.addAll(ilst);
			return true;
		}
		return false;
	}

	@Override
	public boolean updateQty(int cid,int iid,int qty) {
		if(imap.containsKey(new Customer(cid))) {
			List<Item> list = imap.get(new Customer(cid));
			for(Item i : list) {
				if(i.getItemno() == iid) {
					i.setQty(qty);
					return true;
				}
			}
		}
		return false;
	}

	@Override
	public boolean removeItem(int cid, int iid) {
//		if(imap.containsKey(new Customer(cid))) {
//			List<Item> list = imap.get(new Customer(cid));
//			list.remove(new Item(iid));
//			return true;
//		}
//		return false;
		for(Map.Entry<Customer, List<Item>> ls : imap.entrySet()) {
			if(ls.getKey().getCid()==cid) {
				ls.getValue().remove(new Item(iid));
				return true;
			}
		}
		return false;
		
	}

	@Override
	public List<Item> listOrder(int cid) {
		if(imap.containsKey(new Customer(cid))) {
			return imap.get(new Customer(cid));
		}
		return null;
		
	}

	@Override
	public List<Item> listByNameOfItem(int cid,String itemn) {
		List<Item> list = new ArrayList<>();
		if(imap.containsKey(new Customer(cid))) {
			for(Item i: imap.get(new Customer(cid))) {
				if(i.getIname().equals(itemn)) {
					list.add(i);
					return list;
				}
			}
			
		}
	
		return null;
	}

	@Override
	public double totalAmtOfOrder(int cid) {
		double Total = 0;
		if(imap.containsKey(new Customer(cid))) {
			for(Item i : imap.get(new Customer(cid))) {
				Total += i.Total();
			}
		}
		return Total;
	}
	
	

}
