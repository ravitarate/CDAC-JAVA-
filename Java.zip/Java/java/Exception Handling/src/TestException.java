
public class TestException {

	public static void main(String[] args) {
//		int[] arr = {2,3,4,5,6,7};
//		
//		try {
//			for(int i = 0; i<=arr.length; i++) {
//				System.out.println(arr[i]);
//			}
//		}catch(ArrayIndexOutOfBoundsException e) {
//			System.out.println(e.getMessage());
//		}
		try {
			divide(2,0);
		}catch(ArithmeticException e) {
			System.out.println("Trying to divide by zero");
		}

	}
	
	public static int divide(int a, int b) {
		try {
		return a/b;
		
		}catch(ArithmeticException e) {
			System.out.println("Trying to divide by zero");
			throw e;
			
		}
	}

}
