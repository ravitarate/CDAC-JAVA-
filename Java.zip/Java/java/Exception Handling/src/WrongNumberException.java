
public class WrongNumberException extends Exception{
	public WrongNumberException(String msg) {
		super(msg);
	}
}
